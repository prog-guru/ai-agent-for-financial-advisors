(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/auth.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "checkAuth",
    ()=>checkAuth,
    "createSessionFromToken",
    ()=>createSessionFromToken,
    "getMe",
    ()=>getMe,
    "loginWithGoogle",
    ()=>loginWithGoogle,
    "logout",
    ()=>logout,
    "useAuth",
    ()=>useAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
const API = ("TURBOPACK compile-time value", "http://localhost:8000/api");
async function getMe() {
    const res = await fetch("".concat(API, "/auth/me"), {
        credentials: "include",
        cache: "no-store",
        headers: {
            "cache-control": "no-cache",
            pragma: "no-cache"
        }
    });
    return res.json();
}
function loginWithGoogle() {
    window.location.href = "".concat(API, "/auth/google/login");
}
async function logout() {
    await fetch("".concat(API, "/auth/logout"), {
        method: "POST",
        credentials: "include"
    });
    window.location.reload();
}
async function checkAuth() {
    try {
        const result = await getMe();
        return result.authenticated;
    } catch (error) {
        console.error('Auth check failed:', error);
        return false;
    }
}
async function createSessionFromToken(token) {
    try {
        const response = await fetch("".concat(API, "/auth/session"), {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token
            })
        });
        if (response.ok) {
            const data = await response.json();
            console.log('Session created successfully');
            return data.user;
        } else {
            console.error('Failed to create session');
            return {
                authenticated: false
            };
        }
    } catch (error) {
        console.error('Error creating session:', error);
        return {
            authenticated: false
        };
    }
}
function useAuth() {
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAuth.useEffect": ()=>{
            checkAuthStatus();
        }
    }["useAuth.useEffect"], []);
    const checkAuthStatus = async ()=>{
        try {
            const authStatus = await getMe();
            setUser(authStatus);
        } catch (error) {
            console.error('Auth check failed:', error);
            setUser({
                authenticated: false
            });
        } finally{
            setLoading(false);
        }
    };
    return {
        user,
        loading,
        loginWithGoogle,
        logout,
        checkAuthStatus
    };
}
_s(useAuth, "NiO5z6JIqzX62LS5UWDgIqbZYyY=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/auth-callback/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/auth-callback/page.tsx
__turbopack_context__.s([
    "default",
    ()=>AuthCallbackPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function AuthCallbackPage() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthCallbackPage.useEffect": ()=>{
            const processAuthCallback = {
                "AuthCallbackPage.useEffect.processAuthCallback": async ()=>{
                    // Get token from URL parameters
                    const urlParams = new URLSearchParams(window.location.search);
                    const token = urlParams.get('token');
                    console.log('Auth callback received, processing token...');
                    if (token) {
                        try {
                            // Create session and get user details
                            const userData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createSessionFromToken"])(token);
                            console.log("userdata", userData);
                            if (userData.authenticated) {
                                console.log('Authentication successful:', userData.user.email);
                                // Remove token from URL for security
                                window.history.replaceState({}, '', '/');
                                // Redirect to chat/dashboard page
                                router.push('/chat');
                            } else {
                                console.error('Authentication failed');
                                router.push('/login?error=auth_failed');
                            }
                        } catch (error) {
                            console.error('Error during authentication:', error);
                            router.push('/login?error=network_error');
                        }
                    } else {
                        console.error('No token found in URL');
                        router.push('/login?error=no_token');
                    }
                }
            }["AuthCallbackPage.useEffect.processAuthCallback"];
            processAuthCallback();
        }
    }["AuthCallbackPage.useEffect"], [
        router
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen flex items-center justify-center",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-2xl font-bold mb-4",
                    children: "Completing Sign In..."
                }, void 0, false, {
                    fileName: "[project]/src/app/auth-callback/page.tsx",
                    lineNumber: 51,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-600 mb-4",
                    children: "Setting up your account and preferences."
                }, void 0, false, {
                    fileName: "[project]/src/app/auth-callback/page.tsx",
                    lineNumber: 52,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto"
                }, void 0, false, {
                    fileName: "[project]/src/app/auth-callback/page.tsx",
                    lineNumber: 53,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/auth-callback/page.tsx",
            lineNumber: 50,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/auth-callback/page.tsx",
        lineNumber: 49,
        columnNumber: 5
    }, this);
}
_s(AuthCallbackPage, "vQduR7x+OPXj6PSmJyFnf+hU7bg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = AuthCallbackPage;
var _c;
__turbopack_context__.k.register(_c, "AuthCallbackPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/next/navigation.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/client/components/navigation.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=_3eb657c4._.js.map