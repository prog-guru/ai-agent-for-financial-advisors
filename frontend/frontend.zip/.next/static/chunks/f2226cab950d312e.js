__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/aebb09e6500a6194.js",
  "static/chunks/turbopack-13c7ab19ba999bad.js"
])
