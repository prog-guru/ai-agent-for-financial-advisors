__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/aebb09e6500a6194.js",
  "static/chunks/turbopack-5ed88e0efe85fffa.js"
])
