globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/aebb09e6500a6194.js",
      "static/chunks/turbopack-13c7ab19ba999bad.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/aebb09e6500a6194.js",
      "static/chunks/turbopack-5ed88e0efe85fffa.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/3eba6931cad880e3.js",
    "static/chunks/522518d740397639.js",
    "static/chunks/46d600827f558cc3.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/turbopack-7cab01bbc9ded4fd.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];